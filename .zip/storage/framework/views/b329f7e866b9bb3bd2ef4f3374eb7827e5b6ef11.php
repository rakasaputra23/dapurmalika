<header>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
            <li><a href="<?php echo e(route('menu')); ?>">Menu</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Kontak</a></li>
            <li><a href="<?php echo e(route('admin.login')); ?>">Admin</a></li>
        </ul>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\dapurmalika\resources\views\partials\header.blade.php ENDPATH**/ ?>