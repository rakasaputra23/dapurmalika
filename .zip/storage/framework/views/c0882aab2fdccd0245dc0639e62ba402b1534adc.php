

<?php $__env->startSection('content'); ?>
    <div class="content-box">
        <p style="font-size: 16px; color: #555; line-height: 1.6; margin-bottom: 20px;">
            Halo Admin Dapur Malika,
        </p>

        <p style="font-size: 15px; color: #555; line-height: 1.6; margin-bottom: 25px;">
            Kami menerima permintaan reset password untuk akun Anda. Silakan klik tombol di bawah ini untuk mengatur ulang password Anda:
        </p>

        <div style="text-align: center; margin: 30px 0;">
            <a href="<?php echo e($url); ?>" class="button">
                Reset Password
            </a>
        </div>

        <div class="notice">
            <strong>Perhatian:</strong> Link ini akan kedaluwarsa dalam <?php echo e($count); ?> menit.<br>
            Jika Anda tidak meminta reset password, abaikan email ini.
        </div>

        <p style="font-size: 15px; color: #555; line-height: 1.6; margin-top: 25px;">
            Salam hangat,<br>
            <strong>Tim Dapur Malika</strong>
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.mail.html.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dapurmalika\resources\views/vendor/mail/html/password-reset.blade.php ENDPATH**/ ?>