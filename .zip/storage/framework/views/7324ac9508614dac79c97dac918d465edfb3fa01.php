<h2>Pesan Baru dari Form Kontak</h2>

<p><strong>Nama:</strong> <?php echo e($data['name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Telepon:</strong> <?php echo e($data['phone']); ?></p>
<p><strong>Subjek:</strong> <?php echo e($data['subject']); ?></p>
<p><strong>Pesan:</strong></p>
<p><?php echo e($data['message']); ?></p>
<?php /**PATH C:\xampp\htdocs\dapurmalika\resources\views\emails\kontak.blade.php ENDPATH**/ ?>