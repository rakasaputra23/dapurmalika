<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?php echo e($subject ?? 'Dapur Malika Notification'); ?></title>
    <style type="text/css">
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #333;
        }
        
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            padding: 20px 0;
        }
        
        .logo {
            height: 60px;
        }
        
        .content-box {
            background: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        
        .button {
            display: inline-block;
            background-color: #ff9800;
            color: #ffffff;
            padding: 12px 30px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 15px;
            box-shadow: 0 4px 10px rgba(255, 152, 0, 0.3);
        }
        
        .notice {
            background: #fff8f0;
            border-left: 4px solid #ff9800;
            padding: 15px;
            margin: 25px 0;
            border-radius: 0 4px 4px 0;
            font-size: 14px;
            color: #666;
            line-height: 1.5;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #999;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <img src="<?php echo e(asset('images/logo-dapur-malika.png')); ?>" alt="Dapur Malika" class="logo">
        </div>
        
        <?php echo e($slot); ?>

        
        <div class="footer">
            &copy; <?php echo e(date('Y')); ?> Dapur Malika. All rights reserved.
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\dapurmalika\resources\views/vendor/mail/html/layout.blade.php ENDPATH**/ ?>