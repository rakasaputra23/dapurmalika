<header>
    <nav>
        <ul>
            <li><a href="{{ route('home') }}">Beranda</a></li>
            <li><a href="{{ route('menu') }}">Menu</a></li>
            <li><a href="{{ route('contact') }}">Kontak</a></li>
            <li><a href="{{ route('admin.login') }}">Admin</a></li>
        </ul>
    </nav>
</header>
